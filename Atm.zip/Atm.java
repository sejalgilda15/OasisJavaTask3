/*
 oasis infobyte
java programming internship
Task 3:- Atm Interface
by:- Ajay Jadhav
 */

import java.io.IOException;

public class ATM extends MenuOption {
	public static void main(String[] args) throws IOException {
		MenuOption menuOption = new MenuOption();

		menuOption.getLogin();
	}
}